var exp = require("express");
    app = exp(),
    db = require("mongoose"),
    bp = require("body-parser");
    passport = require("passport");
    localstrategy = require("passport-local");
    passportlocalmongoose = require("passport-local-mongoose");
    jwt = require('jsonwebtoken');


db.set('useUnifiedTopology',true);
db.connect("mongodb://localhost:27017/localtradingapp",{useNewUrlParser: true});


userschema = new db.Schema({
    username : String,
    password : String
});

user_info = new db.Schema({
    name : String,
    address : String,
    phonenumber : String,
    user_type:  String
}),

userschema.plugin(passportlocalmongoose);

users =  db.model("User", userschema);
user_info = db.model("User_Info",user_info);


passport.use(new localstrategy(users.authenticate()));
passport.serializeUser(users.serializeUser());
passport.deserializeUser(users.deserializeUser());

app.use(passport.initialize());
app.use(exp.json());

function tokenverify(req,res,next){
    console.log(req.body);
    try {
        token = req.body.tokens;
        decodedToken = jwt.verify(token, 'RANDOM_TOKEN_SECRET');
        console.log(decodedToken);
        userId = decodedToken.userId;
        if (!userId) {
          res.status(404).send();
        } else {
            req.currentuser =  userId;
            next();
        }
      } catch {
        res.status(401).json({
          error: new Error('Invalid request!')
        });
      }
}
app.get("/",function(req,res){
});

app.post("/login",function(req, res,next){
    passport.authenticate('local', function(err, user, info) {
        if (err) { return next(err); }

        if (!user) { return res.status(202).send("usernotfound");}

        req.logIn(user, function(err) {
            if (err) { return next(err); }
            token = jwt.sign({ userId: user._id },'RANDOM_TOKEN_SECRET',{ expiresIn: '24h' });
            return res.status(200).json({tokens: token});
        });
      })(req, res, next);
});

app.post("/token",tokenverify,function(req,res){
    console.log(req.body);
    users.findById(req.currentuser,function(err,usr){
        if(!err){
            res.send(usr.username);
        }
        else{
            console.log(err);
        }
    });
});

app.get("/logincomplete",function(req,res){
    res.status(200).send("loggedin");
});

app.get("/signup",function(req,res){
    res.send("signup Complete");
});

app.post("/signup",function(req,res){
    console.log(req.body);
    users.register(new users({username: req.body.username}),req.body.password,function(err, user){
        if(err){
            console.log(err);
            return res.status(404).send();
        }
        passport.authenticate("local")(req, res, function(){
            console.log("signedup")
            token = jwt.sign({ userId: user._id },'RANDOM_TOKEN_SECRET',{ expiresIn: '24h' });
            res.status(200).json({tokens: token});
        });
    });
});
app.post("/update",tokenverify,function(req,res){
    console.log(req.body);
    users.findById(req.currentuser,function(err,usr){
        if(!err){
            res.status(200).send({tokend:req.body.tokens});
        }
        else{
            res.status(404).send();
            console.log(err);
        }
    });
});
app.get("/signout",function(req,res){
    req.logout();
    res.status(200).send();
});


app.listen(3000,function(req,res){
    console.log("server started at port 3000");
});
