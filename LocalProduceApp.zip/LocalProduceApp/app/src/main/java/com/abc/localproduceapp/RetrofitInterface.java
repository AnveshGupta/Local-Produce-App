package com.abc.localproduceapp;

import android.webkit.JsPromptResult;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface RetrofitInterface {
    @GET("/")
    Call<Void> start();
    @POST("/check")
    Call<Void> check(@Header("token") String token);
    @POST("/login")
    Call<JsonElement> login(@Body User user);
    @POST("/signup")
    Call<JsonElement> signup(@Body User user);
    @POST("/update")
    Call<JsonElement> update(@Body JsonElement json);
    @POST("/token")
    Call<String> mainactivity(@Body JsonElement token);
}


