package com.example.company.locproapp;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class customAdapter extends ArrayAdapter<String>{
    private final Activity context;
    private final Integer[] imgid;
    private final String[] item_name;
    private final Integer[] item_price;
    private final String[] item_seller;

    public customAdapter(Activity context,Integer[] imgid,String[] item_name,Integer[] item_price,String[] item_seller) {
        super(context, R.layout.list_item, item_name);
        this.context=context;
        this.imgid=imgid;
        this.item_name=item_name;
        this.item_price = item_price;
        this.item_seller =item_seller;

    }

    @NonNull
    public View getView(int position, View view, @NonNull ViewGroup parent) {
        ViewHolder viewholder;
        if(view ==null){
            LayoutInflater inflater=context.getLayoutInflater();
            view=inflater.inflate(R.layout.list_item, null,true);
            viewholder = new ViewHolder();
            viewholder.nametext = (TextView) view.findViewById(R.id.itemtitle);
            viewholder.imageView = (ImageView) view.findViewById(R.id.itemimg);
            viewholder.pricetext = (TextView) view.findViewById(R.id.itemprice);
            viewholder.sellerText = (TextView) view.findViewById(R.id.itemSeller);
            view.setTag(viewholder);
        }

        viewholder = (ViewHolder) view.getTag();
        viewholder.nametext.setText(item_name[position]);
        viewholder.imageView.setImageResource(imgid[position]);
        viewholder.sellerText.setText(item_seller[position]);
        viewholder.pricetext.setText("₹"+Integer.toString(item_price[position]));
        return view;
    };

    class ViewHolder{
        ImageView imageView;
        TextView nametext;
        TextView pricetext;
        TextView sellerText;
    }
}
