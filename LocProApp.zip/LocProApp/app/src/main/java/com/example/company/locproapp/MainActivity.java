package com.example.company.locproapp;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.ImageView;
        import android.widget.ListView;
        import android.widget.TextView;

        import java.util.ArrayList;
        import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listview;

    Integer[] imgid= new Integer[]{R.drawable.img1, R.drawable.img1,R.drawable.img1, R.drawable.img1,R.drawable.img1, R.drawable.img1,R.drawable.img1, R.drawable.img1,R.drawable.img1, R.drawable.img1};
    String[] item_name={ "item","item","item","item","item","item","item","item","item","item" };
    Integer[] item_price={50,50,50,50,50,50,50,50,50,50};
    String[] item_seller= new String[]{"seller", "seller","seller", "seller","seller", "seller","seller", "seller","seller", "seller"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview = (ListView) findViewById(R.id.itemList);
        customAdapter adapter = new customAdapter(this,imgid,item_name,item_price,item_seller);
        listview.setAdapter(adapter);
    }
}

